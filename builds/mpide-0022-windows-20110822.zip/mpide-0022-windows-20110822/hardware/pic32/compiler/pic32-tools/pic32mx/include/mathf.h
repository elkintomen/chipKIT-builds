
/* This file defines the ANSI C floating-point functions.  It is here
   because:
   1)  we need also the single-precision functions, missing from most
       compilers
   2)  some compilers define some ANSI functions wrong
*/
#ifndef __MATHF_H
#define __MATHF_H

#warning Contents of mathf.h moved to math.h

#endif
