#ifndef __PTHREAD_H__
#define __PTHREAD_H__

#ifdef __cplusplus
extern "C" {
#endif

#warning pthread.h is not provided in this libc

#ifdef __cplusplus
}
#endif

#endif
