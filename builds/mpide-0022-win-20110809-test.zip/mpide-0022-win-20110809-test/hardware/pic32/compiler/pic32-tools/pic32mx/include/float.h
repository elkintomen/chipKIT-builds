#ifndef _FLOAT_H_
#define _FLOAT_H_
#include <machine/float.h>
#endif

